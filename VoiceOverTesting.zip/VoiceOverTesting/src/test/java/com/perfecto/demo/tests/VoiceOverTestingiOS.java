package com.perfecto.demo.tests;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.perfecto.demo.pageObjects.HomeScreenPageObject;
import com.perfecto.demo.pageObjects.LoginScreenPageObject;
import com.perfecto.demo.utils.Utilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import junit.framework.Assert;

public class VoiceOverTestingiOS {
	AppiumDriver driver;
	HomeScreenPageObject homeScreenPageObject;
	LoginScreenPageObject loginScreenPageObject;

	@Parameters({ "deviceID" })
	@Test
	public void voiceovertest(String deviceID) throws InterruptedException {

		// Click on Home
		Utilities.deviceHome(driver);

		// Switch the context to Native
		Utilities.switchToContext(driver, "NATIVE_APP");

		// Launch Maps
		Utilities.openApplication(driver, "Maps");

		// Click on the search bar
		driver.findElementByName("Search for place or address").click();

		// Click on the dictate icon
		driver.findElementByName("Dictate").click();
		
		// Click on Enable dictation - usually comes for first time
		try {
			driver.findElement(By.name("Enable Dictation")).click();
		} catch (Exception NoSuchElementException) {
		}

		// Inject audio
		Utilities.injectAudio(driver, "PUBLIC:rec_1s.mp3");

//		// Click on Done button
		Thread.sleep(5000);
		System.out.println(driver.getPageSource());
		System.out.println(driver.getContextHandles().size());
//		driver.findElement(By.name("Done")).click();

		// Check if the value is London
		Assert.assertEquals("London", driver.findElementByName("Search for place or address").getAttribute("value"));

		// Close Maps
		Utilities.closeApplication(driver, "Maps");

	}

	@Parameters({ "deviceID" })
	@BeforeTest
	public void beforeTest(String deviceID) throws MalformedURLException {
		driver = Utilities.getAppiumDriver(deviceID);
		homeScreenPageObject = new HomeScreenPageObject();
		loginScreenPageObject = new LoginScreenPageObject();
		PageFactory.initElements(new AppiumFieldDecorator(driver, 5, TimeUnit.SECONDS), homeScreenPageObject);
		PageFactory.initElements(new AppiumFieldDecorator(driver, 5, TimeUnit.SECONDS), loginScreenPageObject);
		driver.get("http://www.ebay.com");
	}

	@Parameters({ "deviceID" })
	@AfterTest
	public void afterTest(String deviceID) throws IOException {
		driver.close();
		Utilities.downloadReport(driver, "html", "FP_" + deviceID);
		driver.quit();
	}

}
